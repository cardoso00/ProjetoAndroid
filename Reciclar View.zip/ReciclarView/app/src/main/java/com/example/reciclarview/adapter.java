package com.example.reciclarview;

    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.TextView;
    import androidx.annotation.NonNull;
    import java.util.List;
    import androidx.recyclerview.widget.RecyclerView;

public class adapter extends RecyclerView.Adapter<adapter.MyViewHolder> {

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView titulo, ano, genero;


    }
}
