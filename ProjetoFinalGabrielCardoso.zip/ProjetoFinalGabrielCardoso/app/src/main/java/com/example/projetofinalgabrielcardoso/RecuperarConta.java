package com.example.projetofinalgabrielcardoso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RecuperarConta extends AppCompatActivity {

    private EditText recuperarEmail;
    private AppCompatButton bt_recuperar;
    private ImageButton bt_back;
    private FirebaseAuth auth;
    private FirebaseUser user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar_conta);
        this.iniciarComponets();
        this.voltarTelaLogin();
        this.coreRecuperarConta();

    }//fim onCreate

    private void coreRecuperarConta(){
        bt_recuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recuperarConta();
            }
        });
    }//fim coreRecuperarConta

    private void recuperarConta(){
        String email= recuperarEmail.getText().toString();
        auth= FirebaseAuth.getInstance();
        if (email.isEmpty()){//usuario preencheu o email? funçao isEmpty retorna true caso email nao esteja preenchido, porem a !nega o resultado
            //ou seja, se estiver preenchido a funçao retorna falso

            auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(getBaseContext(), "Enviado com Sucesso!", Toast.LENGTH_SHORT).show();
                    }//fim if
                }//fim onComplete
            }).addOnFailureListener(
                    new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            trataErro(e.toString());
                        }
                    }
            );
        }//fim if deu certo
        else{// o usuario nao preencheu o campo email
            Toast.makeText(getBaseContext(), "Insira um Email!", Toast.LENGTH_SHORT).show();
        }//fim else
    }//fim recuperarSenha

    private void trataErro(String erro){
        if (erro.contains("address is badly")){
            Toast.makeText(getBaseContext(), "Email invalido", Toast.LENGTH_SHORT).show();
        }//fim if email invalido

        else if (erro.contains("there is no user")) {
            Toast.makeText(getBaseContext(), "Email não cadastrado", Toast.LENGTH_SHORT).show();
        }//email nao cadastrado

        else if (erro.contains("INVALID_EMAIL")){
            Toast.makeText(getBaseContext(), "Email invalido", Toast.LENGTH_SHORT).show();
        }//email INVALIDO

        else{
            Toast.makeText(getBaseContext(), erro, Toast.LENGTH_SHORT).show();
        }//fim else
    }//fim trata erro
    private void iniciarComponets(){
        recuperarEmail= findViewById(R.id.editTextEmailRecuperarConta);
        bt_recuperar= findViewById(R.id.bt_recuperar);
        bt_back= findViewById(R.id.ButtonBackRecuperarConta);
    }//fim iniciarComponets

    private void voltarTelaLogin(){
        bt_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(RecuperarConta.this, FormLogin.class);
                startActivity(intent);
                finish();
            }
        });
    }
}